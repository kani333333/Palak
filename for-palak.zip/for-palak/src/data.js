export const letterParagraphs = [
  'Hey Palak,',
  'I wanted to make something a little different for you.',
  'Not something huge or complicated. Just a small reminder that even in the middle of busy days, endless responsibilities, and everything life keeps throwing at us, there is always room for a little happiness.',
  'I hope you have plenty of reasons to smile, people who make you feel comfortable being yourself, and moments that remind you how beautiful the little things in life can be.',
  "And whenever things get overwhelming, I hope you remember that you don't have to have everything figured out.",
  "You're allowed to slow down. You're allowed to rest. You're allowed to enjoy the journey instead of constantly worrying about where it will take you.",
  "So here's a tiny corner of the internet made especially for you.",
  'Take your time exploring it, smile at the little surprises, and remember to be kind to yourself along the way.',
  'Keep being you, Palak. ♡',
]

export const reminders = [
  { key: 'smile', title: 'Your Smile', emoji: '☀️', icon: 'Sun', tone: 'butter',
    text: 'Never underestimate the power of a genuine smile. I hope life gives you plenty of reasons to share yours.' },
  { key: 'happy', title: 'Your Happiness', emoji: '💗', icon: 'Heart', tone: 'blush',
    text: 'Your happiness matters, even on ordinary days when nothing particularly special happens.' },
  { key: 'dreams', title: 'Your Dreams', emoji: '✨', icon: 'Sparkles', tone: 'lilac',
    text: "Keep making room for the things you dream about. Big things take time, and that's perfectly okay." },
  { key: 'peace', title: 'Your Peace', emoji: '🦋', icon: 'Feather', tone: 'sky',
    text: "You don't need to figure everything out today. Sometimes, taking a breath is enough." },
  { key: 'kind', title: 'Your Kindness', emoji: '🌸', icon: 'Flower2', tone: 'rose',
    text: 'Never forget to show yourself the same kindness you would offer someone you care about.' },
  { key: 'you', title: 'Just Being You', emoji: '🎀', icon: 'Star', tone: 'peach',
    text: "You don't need to do something extraordinary every day to be someone worth appreciating." },
]

export const doctorCards = [
  { title: 'Prescription for Happiness', emoji: '💊', icon: 'Pill', tone: 'blush',
    text: 'One generous dose of laughter, a little time for yourself, and a reminder that happiness belongs in your routine, too.' },
  { title: 'A Note Between Study Sessions', emoji: '📚', icon: 'NotebookPen', tone: 'lilac',
    text: "To the girl chasing a big dream: remember that every small step counts. You don't need to do everything perfectly to keep moving forward." },
  { title: 'Emergency Reminder', emoji: '🚨', icon: 'Siren', tone: 'rose',
    text: 'Important reminder, future doctor: taking a break is allowed. Rest is not a reward you have to earn after exhausting yourself.' },
  { title: 'Heart Check-Up', emoji: '❤️', icon: 'HeartPulse', tone: 'peach',
    text: "Today's tiny check-up: Have you eaten something? Had enough water? Relaxed your shoulders? Taken a moment to breathe?" },
]

export const boosts = [
  'One step at a time, future Dr. Palak. You\'ve got this! 🩺',
  "Your journey doesn't have to be perfect to be meaningful. 💗",
  'Take a breath. Your dreams are worth pursuing at your own pace. 🌷',
  'A little progress is still progress. Keep going! ✨',
  "Reminder from your unofficial happiness department: don't forget to smile today. 🎀",
  'Every future doctor started with a tired day and a stubborn little hope. 🩺',
  'You are allowed to be proud of how far you have already come. 💗',
]

export const envelopes = [
  { id: 'tired', title: "Open When You're Tired", emoji: '🌙', tone: 'lilac',
    body: `Hey Palak,

Take a deep breath.

You don't need to solve every problem today. You don't need to be productive every second. And you don't need to feel guilty for being tired.

Whatever today has looked like, give yourself permission to slow down for a moment.

Relax your shoulders, drink some water, and let your mind rest.

You can return to your to-do list later.

For now, you deserve a little peace, too. 💗` },
  { id: 'motivation', title: 'Open When You Need Motivation', emoji: '✨', tone: 'butter',
    body: `Dear Palak,

Remember the dreams you're working toward.

Some days will feel exciting, and other days might feel like you're moving forward one tiny step at a time.

That's okay.

You don't have to be perfect. You don't have to compare your journey to anyone else's.

Keep learning. Keep trying. Celebrate the little wins, even the ones nobody else notices.

You are allowed to grow at your own pace.

One step at a time, future Dr. Palak. 🩺💗` },
  { id: 'low', title: "Open When You're Feeling Low", emoji: '🦋', tone: 'sky',
    body: `Hey you,

If today feels a little heavier than usual, here's your reminder that one difficult day doesn't define everything.

You are allowed to feel tired. You are allowed to have complicated feelings. You are allowed to take things slowly.

You don't need to pretend that everything is perfect.

Be gentle with yourself, Palak.

I hope something small and unexpected makes you smile today.

Maybe a favorite song, a good conversation, a beautiful sunset, or even this little message finding you at just the right moment. 🌷` },
  { id: 'smile', title: 'Open When You Need a Smile', emoji: '🎀', tone: 'rose',
    body: `Surprise, Palak! 💗

Imagine a tiny penguin wearing a doctor's coat, carrying a bouquet of flowers, and walking into the room with an extremely important announcement.

"Doctor Palak, your daily happiness check-up is overdue!"

Diagnosis: You deserve a little extra joy today.

Recommended treatment: Something delicious, a little music, a few moments of peace, and absolutely no guilt about enjoying yourself.

Possible side effects include smiling at your screen.

Prescription complete. 🩺✨` },
]

export const wishes = [
  'More reasons to laugh until your cheeks hurt.',
  'People who make you feel safe being yourself.',
  'Beautiful memories in the middle of ordinary days.',
  'The courage to keep pursuing the dreams that matter to you.',
  'Enough rest, even when life gets busy.',
  'Unexpected little moments that make an ordinary day feel special.',
]

export const giftParagraphs = [
  "Palak, here's one little reminder for you.",
  "You don't have to be extraordinary every single day.",
  "You don't have to have all the answers.",
  "You don't have to turn every difficult moment into a success story.",
  'Sometimes, simply showing up, trying again, and giving yourself another chance is more than enough.',
  'I hope your journey brings you beautiful friendships, meaningful experiences, unexpected happiness, and countless reasons to feel proud of yourself.',
  'I hope you find moments that make you laugh unexpectedly, people who make ordinary days feel special, and little things that remind you why life can be beautiful.',
  'Keep your dreams alive, your heart kind, and your smile close.',
  'And whenever life gets a little too busy, remember to pause and enjoy the little things.',
  'You deserve those moments, too. 💗',
]

export const finalParagraphs = [
  'Whatever today looks like, I hope you find at least one reason to smile.',
  "I hope you remember that your worth isn't measured by how much you accomplish.",
  'I hope life surprises you in beautiful ways.',
  'I hope you give yourself permission to rest when you need it and celebrate yourself when something goes right.',
  'And I hope you never forget to save a little kindness for yourself.',
  'Keep growing, keep dreaming, and keep being you.',
  'The world has enough reasons to be serious.',
  'You deserve a few little reasons to smile, too. 💗',
]

// The brief was cut off at "Send Me One…", so this final button is my best guess.
export const lastSmiles = [
  'Smile delivered. Handle with care, it is very contagious. 😊',
  'Another one, just for you: you are doing better than you think. 💗',
  'Delivered with extra sparkle. Now go drink some water. 💧✨',
  'One more: the world is a little brighter with you in it. ☀️',
]
