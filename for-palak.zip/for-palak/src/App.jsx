import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import {
  Sun, Heart, Sparkles, Feather, Flower2, Star, Pill, NotebookPen, Siren, HeartPulse,
  Stethoscope, ClipboardList, Cross, ChevronDown, X, RotateCcw,
} from 'lucide-react'
import {
  letterParagraphs, reminders, doctorCards, boosts, envelopes, wishes,
  giftParagraphs, finalParagraphs, lastSmiles,
} from './data.js'

const ICONS = { Sun, Heart, Sparkles, Feather, Flower2, Star, Pill, NotebookPen, Siren, HeartPulse }

/* ---------- helpers ---------- */
function rng(seed) {
  let a = seed
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function scrollToId(id) {
  const el = document.getElementById(id)
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

function pickDifferent(list, last) {
  if (list.length < 2) return 0
  let i
  do { i = Math.floor(Math.random() * list.length) } while (i === last)
  return i
}

/* Ambient floating decorations (pure CSS animation, fixed count so nothing piles up) */
function Floaters({ seed = 1, hearts = 8, glyphs = 6, stars = 14, glyphSet = ['✿', '❀', '✦'] }) {
  const items = useMemo(() => {
    const r = rng(seed)
    const out = []
    for (let i = 0; i < hearts; i++)
      out.push({ k: 'h' + i, c: '♥', cls: 'fl fl-heart', left: r() * 100, size: 12 + r() * 16, dur: 14 + r() * 12, delay: -r() * 20, op: 0.25 + r() * 0.3 })
    for (let i = 0; i < glyphs; i++)
      out.push({ k: 'g' + i, c: glyphSet[i % glyphSet.length], cls: 'fl fl-petal', left: r() * 100, size: 14 + r() * 14, dur: 18 + r() * 14, delay: -r() * 24, op: 0.3 + r() * 0.25 })
    for (let i = 0; i < stars; i++)
      out.push({ k: 's' + i, c: '✦', cls: 'twinkle', left: r() * 100, top: r() * 100, size: 6 + r() * 9, dur: 2.5 + r() * 3.5, delay: -r() * 5 })
    return out
  }, [seed, hearts, glyphs, stars, glyphSet])

  return (
    <div className="floaters" aria-hidden="true">
      {items.map((it) => (
        <span key={it.k} className={it.cls}
          style={{ left: it.left + '%', top: it.top != null ? it.top + '%' : undefined, fontSize: it.size,
            animationDuration: it.dur + 's', animationDelay: it.delay + 's', '--op': it.op }}>
          {it.c}
        </span>
      ))}
    </div>
  )
}

/* Heart burst from a screen point. Capped and self-cleaning. */
function useBurst() {
  const [bursts, setBursts] = useState([])
  const fire = useCallback((x, y, count = 12) => {
    const id = Math.random().toString(36).slice(2)
    const items = Array.from({ length: count }, (_, i) => ({
      i, dx: (Math.random() - 0.5) * 220, dy: -(90 + Math.random() * 190),
      s: 0.7 + Math.random() * 0.9, ch: ['💗', '♥', '✨', '💕', '🌸'][i % 5], d: Math.random() * 0.15,
    }))
    setBursts((b) => [...b.slice(-2), { id, x, y, items }])
    setTimeout(() => setBursts((b) => b.filter((q) => q.id !== id)), 2000)
  }, [])
  const layer = (
    <div className="burst-layer" aria-hidden="true">
      {bursts.map((b) => b.items.map((it) => (
        <motion.span key={b.id + it.i} className="burst-heart" style={{ left: b.x, top: b.y, fontSize: 18 * it.s }}
          initial={{ opacity: 0, x: 0, y: 0, scale: 0.3 }}
          animate={{ opacity: [0, 1, 1, 0], x: it.dx, y: it.dy, scale: it.s, rotate: it.dx / 8 }}
          transition={{ duration: 1.6, delay: it.d, ease: 'easeOut' }}>
          {it.ch}
        </motion.span>
      )))}
    </div>
  )
  return [layer, fire]
}

const fadeUp = (i = 0) => ({
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-60px' },
  transition: { duration: 0.7, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
})

function SectionHead({ title, sub, hand }) {
  return (
    <header className="sec-head">
      <motion.h2 {...fadeUp(0)}>{title}</motion.h2>
      {sub && <motion.p className="sub" {...fadeUp(1)}>{sub}</motion.p>}
      {hand && <motion.p className="hand" {...fadeUp(2)}>{hand}</motion.p>}
    </header>
  )
}

function NextButton({ to, children }) {
  return (
    <motion.button className="pill pill-soft" onClick={() => scrollToId(to)}
      whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}>
      {children}
    </motion.button>
  )
}

/* ---------- 1. Welcome ---------- */
function Welcome({ onOpen, glow }) {
  const [layer, fire] = useBurst()
  const click = (e) => {
    const r = e.currentTarget.getBoundingClientRect()
    fire(r.left + r.width / 2, r.top + r.height / 2, 14)
    onOpen()
  }
  return (
    <section id="welcome" className="sec welcome" aria-label="Welcome">
      <Floaters seed={7} hearts={9} glyphs={7} stars={26} glyphSet={['✿', '❀', '✦', '❁']} />
      <div className={'glow-pulse' + (glow ? ' on' : '')} aria-hidden="true" />
      {layer}
      <div className="welcome-inner">
        <motion.p className="intro" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.9 }}>
          A little something, made just for you...
        </motion.p>
        <motion.h1 className="name-glow" initial={{ opacity: 0, scale: 0.9, filter: 'blur(10px)' }}
          animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }} transition={{ delay: 0.5, duration: 1.3, ease: [0.22, 1, 0.36, 1] }}>
          Hey, Palak! <span className="heart-inline">♡</span>
        </motion.h1>
        <motion.p className="lead" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2, duration: 0.9 }}>
          I made a little corner of the internet just for you.
        </motion.p>
        <motion.p className="hand" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5, duration: 0.9 }}>
          Because everyone deserves a little extra happiness sometimes. 💗
        </motion.p>
        <motion.button className="pill pill-main" onClick={click}
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.8, duration: 0.8 }}
          whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.94 }}>
          Open Your Little Surprise ✨
        </motion.button>
      </div>
      <div className="welcome-foot">
        <p>Made with a little extra love, just for you. ♡</p>
        <motion.span className="scroll-cue" aria-hidden="true" animate={{ y: [0, 8, 0] }} transition={{ repeat: Infinity, duration: 1.8 }}>
          <ChevronDown size={22} />
        </motion.span>
      </div>
    </section>
  )
}

/* ---------- 2. Letter ---------- */
function Letter() {
  return (
    <section id="letter" className="sec letter-sec" aria-label="A letter for Palak">
      <Floaters seed={21} hearts={4} glyphs={3} stars={6} />
      <motion.article className="paper" {...fadeUp(0)}>
        <motion.div animate={{ y: [0, -6, 0] }} transition={{ repeat: Infinity, duration: 6, ease: 'easeInOut' }}>
          <motion.h2 className="letter-title" {...fadeUp(0)}>Dear Palak, 💗</motion.h2>
          {letterParagraphs.map((p, i) => (
            <motion.p key={i} className="letter-p" {...fadeUp(Math.min(i, 5) * 0.6)}>{p}</motion.p>
          ))}
          <motion.div className="signoff" {...fadeUp(1)}>
            <p className="hand big">Sending a little sunshine your way,</p>
            <p className="hand big sig">Someone who wanted to make you smile. 💗
              <motion.span className="tiny-heart" aria-hidden="true"
                initial={{ scale: 0, opacity: 0 }} whileInView={{ scale: 1, opacity: 1 }} viewport={{ once: true }}
                transition={{ delay: 1, type: 'spring', stiffness: 200 }}>♡</motion.span>
            </p>
          </motion.div>
        </motion.div>
      </motion.article>
      <NextButton to="reminders">There's More for You ♡</NextButton>
    </section>
  )
}

/* ---------- 3. Reminders ---------- */
function Reminders() {
  return (
    <section id="reminders" className="sec reminders-sec" aria-label="Little reminders">
      <SectionHead title="Little Things I Hope You Never Forget" sub="Just a few tiny reminders for someone who deserves them." />
      <div className="grid-cards">
        {reminders.map((r, i) => {
          const Icon = ICONS[r.icon]
          return (
            <motion.article key={r.key} className={'card tone-' + r.tone}
              initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }}
              transition={{ delay: (i % 3) * 0.12, duration: 0.7 }}
              whileHover={{ y: -8, rotate: i % 2 ? 0.8 : -0.8 }} whileTap={{ scale: 0.97 }}>
              <motion.span className="icon-bubble" initial={{ scale: 0 }} whileInView={{ scale: 1 }} viewport={{ once: true }}
                transition={{ delay: 0.3 + (i % 3) * 0.12, type: 'spring', stiffness: 220 }} whileHover={{ rotate: 12, scale: 1.12 }}>
                <Icon size={22} strokeWidth={1.8} />
              </motion.span>
              <h3>{r.title} <span aria-hidden="true">{r.emoji}</span></h3>
              <p>{r.text}</p>
            </motion.article>
          )
        })}
      </div>
    </section>
  )
}

/* ---------- 4. Future doctor ---------- */
function StethoscopeArt() {
  return (
    <motion.svg viewBox="0 0 120 120" className="steth" role="img" aria-label="A cute stethoscope"
      whileHover={{ rotate: [0, -6, 5, -3, 0] }} transition={{ duration: 0.9 }}>
      <path d="M30 14 v26 a22 22 0 0 0 44 0 v-26" fill="none" stroke="#793D56" strokeWidth="5" strokeLinecap="round" />
      <circle cx="30" cy="12" r="5" fill="#EFA9BF" stroke="#793D56" strokeWidth="3" />
      <circle cx="74" cy="12" r="5" fill="#EFA9BF" stroke="#793D56" strokeWidth="3" />
      <path d="M52 62 v14 a22 22 0 0 0 44 0 v-8" fill="none" stroke="#793D56" strokeWidth="5" strokeLinecap="round" />
      <circle cx="96" cy="60" r="11" fill="#F8DCE5" stroke="#C99A8B" strokeWidth="5" />
      <path d="M96 55.5 c-1.6-3-5.5-1.6-5 1.4 c.4 2.3 3 3.6 5 5.2 c2-1.6 4.6-2.9 5-5.2 c.5-3-3.4-4.4-5-1.4z" fill="#793D56" />
    </motion.svg>
  )
}

function Ecg() {
  return (
    <svg viewBox="0 0 300 60" className="ecg" aria-hidden="true" preserveAspectRatio="none">
      <path className="ecg-line" d="M0 32 H70 l8-4 8 4 H108 l8 6 10-30 12 46 8-22 H170 l8-5 10 5 H300"
        fill="none" stroke="#793D56" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Doctor() {
  const [idx, setIdx] = useState(-1)
  const next = () => setIdx((cur) => pickDifferent(boosts, cur))
  const floaters = [
    { I: Pill, x: '8%', y: '10%', d: 0 }, { I: Cross, x: '88%', y: '8%', d: 1 },
    { I: ClipboardList, x: '92%', y: '58%', d: 2 }, { I: NotebookPen, x: '4%', y: '62%', d: 1.5 },
    { I: Stethoscope, x: '50%', y: '2%', d: 0.7 },
  ]
  return (
    <section id="doctor" className="sec doctor-sec" aria-label="For the future doctor">
      <Floaters seed={55} hearts={5} glyphs={0} stars={12} />
      {floaters.map(({ I, x, y, d }, i) => (
        <motion.span key={i} className="med-float" aria-hidden="true" style={{ left: x, top: y }}
          animate={{ y: [0, -12, 0], rotate: [0, 6, 0] }} transition={{ repeat: Infinity, duration: 5 + d, delay: d, ease: 'easeInOut' }}>
          <I size={22} strokeWidth={1.6} />
        </motion.span>
      ))}
      <SectionHead title="For the Future Doctor, Palak 🩺"
        sub="Studying medicine is a journey of dedication, patience, and learning. Here's a little reminder to take care of yourself along the way." />
      <motion.div className="med-hero" {...fadeUp(0)}>
        <StethoscopeArt />
        <div className="ecg-card">
          <motion.span className="pulse-heart" aria-hidden="true" animate={{ scale: [1, 1.18, 1, 1.12, 1] }}
            transition={{ repeat: Infinity, duration: 1.6, ease: 'easeInOut' }}>❤</motion.span>
          <Ecg />
          <p className="hand">just a decorative heartbeat ♡</p>
        </div>
      </motion.div>
      <div className="grid-cards four">
        {doctorCards.map((c, i) => {
          const Icon = ICONS[c.icon]
          return (
            <motion.article key={c.title} className={'card tone-' + c.tone} {...fadeUp(i % 2)} whileHover={{ y: -6 }} whileTap={{ scale: 0.97 }}>
              <span className="icon-bubble"><Icon size={22} strokeWidth={1.8} /></span>
              <h3>{c.title} <span aria-hidden="true">{c.emoji}</span></h3>
              <p>{c.text}</p>
            </motion.article>
          )
        })}
      </div>
      <motion.p className="hand big center" {...fadeUp(0)}>Even future doctors deserve a little looking-after, too. ♡</motion.p>
      <div className="boost" aria-live="polite">
        <motion.button className="pill pill-main" onClick={next} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.94 }}>
          Give Future Dr. Palak a Little Boost ✨
        </motion.button>
        <div className="boost-slot">
          <AnimatePresence mode="wait">
            {idx >= 0 && (
              <motion.p key={idx + boosts[idx]} className="boost-msg" initial={{ opacity: 0, y: 14, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.4 }}>
                {boosts[idx]}
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>
      <p className="disclaimer">These are friendly reminders, not medical advice or an actual prescription. 💗</p>
    </section>
  )
}

/* ---------- 5. Envelopes ---------- */
function Envelope({ env, i, onOpen, opening }) {
  return (
    <motion.button className={'env tone-' + env.tone + (opening ? ' opening' : '')} onClick={() => onOpen(env)}
      aria-haspopup="dialog" aria-label={env.title}
      initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }}
      transition={{ delay: (i % 2) * 0.12, duration: 0.7 }} whileHover={{ y: -8, rotate: i % 2 ? 1.2 : -1.2 }} whileTap={{ scale: 0.96 }}>
      <span className="env-letter" aria-hidden="true" />
      <span className="env-body" aria-hidden="true" />
      <motion.span className="env-flap" aria-hidden="true" animate={{ rotateX: opening ? 180 : 0 }} transition={{ duration: 0.5 }} />
      <span className="env-seal" aria-hidden="true">♥</span>
      <span className="env-title">{env.title} <span aria-hidden="true">{env.emoji}</span></span>
    </motion.button>
  )
}

function LetterModal({ env, onClose }) {
  const ref = useRef(null)
  const closeRef = useRef(null)
  useEffect(() => {
    const prevFocus = document.activeElement
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); onClose() }
      if (e.key === 'Tab' && ref.current) {
        const f = ref.current.querySelectorAll('button, [href], [tabindex]:not([tabindex="-1"])')
        if (!f.length) return
        const first = f[0], last = f[f.length - 1]
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
      prevFocus?.focus?.()
    }
  }, [onClose])

  return (
    <motion.div className="backdrop" onClick={onClose} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div ref={ref} className="sheet" role="dialog" aria-modal="true" aria-labelledby="sheet-title"
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, y: 70, scale: 0.94 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 50, scale: 0.96 }}
        transition={{ type: 'spring', damping: 26, stiffness: 260 }}>
        <button ref={closeRef} className="close-btn" onClick={onClose} aria-label="Close letter"><X size={20} /></button>
        <h3 id="sheet-title" className="sheet-title">{env.title} {env.emoji}</h3>
        <div className="sheet-body">
          {env.body.split('\n\n').map((para, i) => (
            <motion.p key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.07 }}>{para}</motion.p>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}

function Envelopes() {
  const [opening, setOpening] = useState(null)
  const [active, setActive] = useState(null)
  const timer = useRef(null)
  useEffect(() => () => clearTimeout(timer.current), [])
  const open = (env) => {
    if (opening) return
    setOpening(env.id)
    timer.current = setTimeout(() => { setActive(env); setOpening(null) }, 520)
  }
  const close = useCallback(() => setActive(null), [])
  return (
    <section id="envelopes" className="sec env-sec" aria-label="Letters to open">
      <SectionHead title="A Little Note for Every Kind of Day 💌" sub="Pick whichever one feels right for you today." />
      <div className="env-grid">
        {envelopes.map((e, i) => <Envelope key={e.id} env={e} i={i} onOpen={open} opening={opening === e.id} />)}
      </div>
      <AnimatePresence>{active && <LetterModal key={active.id} env={active} onClose={close} />}</AnimatePresence>
    </section>
  )
}

/* ---------- 6. Garden of wishes ---------- */
function Wishes() {
  const [orb, setOrb] = useState(null)
  const last = useRef(-1)
  const send = () => {
    const i = pickDifferent(wishes, last.current)
    last.current = i
    setOrb({ id: Date.now(), text: wishes[i] })
  }
  const sparks = useMemo(() => Array.from({ length: 8 }, (_, i) => ({ a: (i / 8) * Math.PI * 2 })), [])
  return (
    <section id="garden" className="sec garden-sec" aria-label="Garden of good wishes">
      <Floaters seed={91} hearts={4} glyphs={10} stars={18} glyphSet={['✿', '❀', '❁', '✦']} />
      <SectionHead title="Little Things I Hope Life Gives You" sub="Some wishes for your ordinary days and extraordinary dreams." />
      <ul className="wish-grid">
        {wishes.map((w, i) => (
          <motion.li key={w} className={'wish w' + (i % 3)} {...fadeUp(i % 3)} whileHover={{ y: -5 }} whileTap={{ scale: 0.97 }}>
            <span aria-hidden="true" className="wish-flower">{['✿', '❀', '❁'][i % 3]}</span>{w}
          </motion.li>
        ))}
      </ul>
      <motion.button className="pill pill-main" onClick={send} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.94 }}>
        Send a Little Wish Into the Universe ✨
      </motion.button>
      <div className="orb-stage" aria-live="polite">
        <AnimatePresence mode="wait">
          {orb && (
            <motion.div key={orb.id} className="orb-wrap" exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
              <motion.div className="orb" aria-hidden="true" initial={{ y: 120, opacity: 0, scale: 0.4 }}
                animate={{ y: [120, -10, -30], opacity: [0, 1, 1, 0], scale: [0.4, 1, 1.15, 0.8] }}
                transition={{ duration: 1.8, times: [0, 0.5, 0.8, 1], ease: 'easeOut' }}>
                {sparks.map((s, k) => (
                  <motion.i key={k} className="spark" initial={{ opacity: 0, x: 0, y: 0 }}
                    animate={{ opacity: [0, 1, 0], x: Math.cos(s.a) * 46, y: Math.sin(s.a) * 46 }}
                    transition={{ delay: 0.7 + k * 0.03, duration: 0.9 }} />
                ))}
              </motion.div>
              <motion.p className="wish-reveal" initial={{ opacity: 0, y: 14, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: 1.2, duration: 0.7 }}>{orb.text}</motion.p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

/* ---------- 7. Gift box ---------- */
function Gift() {
  const [stage, setStage] = useState('idle') // idle | opening | open
  const [layer, fire] = useBurst()
  const btn = useRef(null)
  const timers = useRef([])
  useEffect(() => () => timers.current.forEach(clearTimeout), [])
  const unwrap = () => {
    if (stage !== 'idle') return
    setStage('opening')
    timers.current.push(setTimeout(() => {
      const r = btn.current?.getBoundingClientRect()
      if (r) fire(r.left + r.width / 2, r.top - 120, 16)
      setStage('open')
    }, 750))
  }
  const replay = () => setStage('idle')
  const isOpen = stage === 'open'
  return (
    <section id="gift" className="sec gift-sec" aria-label="Gift box">
      <Floaters seed={133} hearts={6} glyphs={2} stars={12} />
      {layer}
      <SectionHead title="Wait... There's One More Thing 🎁" sub="I saved one last little surprise for you." />
      <motion.div className="gift-stage" animate={stage === 'idle' ? { y: [0, -10, 0] } : { y: 0 }}
        transition={stage === 'idle' ? { repeat: Infinity, duration: 3.6, ease: 'easeInOut' } : {}}>
        <AnimatePresence>
          {isOpen && (
            <motion.div className="gift-card" initial={{ y: 130, opacity: 0, scale: 0.8 }} animate={{ y: 0, opacity: 1, scale: 1 }}
              transition={{ type: 'spring', damping: 18, stiffness: 120 }}>
              {giftParagraphs.map((p, i) => (
                <motion.p key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + i * 0.12 }}>{p}</motion.p>
              ))}
              <motion.p className="hand big center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 + giftParagraphs.length * 0.12 }}>
                Sending a little sunshine your way, Palak. ☀️
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>
        <motion.div className="box" animate={stage === 'opening' ? { rotate: [0, -4, 4, -3, 3, 0] } : { rotate: 0 }} transition={{ duration: 0.7 }}>
          <motion.div className="lid" animate={isOpen ? { y: -62, rotate: -24, x: -26 } : { y: 0, rotate: 0, x: 0 }}
            transition={{ type: 'spring', damping: 12, stiffness: 120 }}>
            <span className="bow" aria-hidden="true" />
          </motion.div>
          <div className="box-body"><Heart className="box-heart" size={34} fill="#fff8f2" strokeWidth={0} /></div>
        </motion.div>
        <div className="box-shadow" aria-hidden="true" />
      </motion.div>
      <div ref={btn} className="gift-actions">
        {stage !== 'open' ? (
          <motion.button className="pill pill-main" onClick={unwrap} disabled={stage === 'opening'} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.94 }}>
            Unwrap Your Surprise 💝
          </motion.button>
        ) : (
          <button className="text-btn" onClick={replay}><RotateCcw size={14} /> Replay the unwrapping</button>
        )}
      </div>
    </section>
  )
}

/* ---------- 8. Final ---------- */
function Final() {
  const [layer, fire] = useBurst()
  const [n, setN] = useState(-1)
  const click = (e) => {
    const r = e.currentTarget.getBoundingClientRect()
    fire(r.left + r.width / 2, r.top, 14)
    setN((c) => (c + 1) % lastSmiles.length)
  }
  return (
    <section id="final" className="sec final-sec" aria-label="One last reminder">
      <Floaters seed={200} hearts={12} glyphs={3} stars={16} />
      {layer}
      <SectionHead title="One Last Little Reminder, Palak..." />
      <div className="final-msg">
        {finalParagraphs.map((p, i) => <motion.p key={i} {...fadeUp(0)}>{p}</motion.p>)}
      </div>
      <motion.p className="signature" {...fadeUp(0)}>Palak ♡</motion.p>
      <motion.p className="hand big center" {...fadeUp(1)}>A little corner of happiness, made just for you.</motion.p>
      <motion.span className="final-heart" aria-hidden="true" animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1.8 }}>💗</motion.span>
      <motion.button className="pill pill-main" onClick={click} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.94 }}>
        Send Me One Last Smile 💗
      </motion.button>
      <div className="boost-slot" aria-live="polite">
        <AnimatePresence mode="wait">
          {n >= 0 && (
            <motion.p key={n + lastSmiles[n]} className="boost-msg" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {lastSmiles[n]}
            </motion.p>
          )}
        </AnimatePresence>
      </div>
      <p className="made">Made with a little extra love, just for you. ♡</p>
    </section>
  )
}

/* ---------- App ---------- */
export default function App() {
  const [opened, setOpened] = useState(false)
  const [glow, setGlow] = useState(false)
  const open = () => {
    setGlow(true)
    setTimeout(() => setGlow(false), 1200)
    if (!opened) setOpened(true)
    setTimeout(() => scrollToId('letter'), opened ? 50 : 350)
  }
  return (
    <MotionConfig reducedMotion="user">
      <main>
        <Welcome onOpen={open} glow={glow} />
        {opened && (
          <>
            <Letter />
            <Reminders />
            <Doctor />
            <Envelopes />
            <Wishes />
            <Gift />
            <Final />
          </>
        )}
      </main>
    </MotionConfig>
  )
}
